import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-animalcare',
  templateUrl: './animalcare.page.html',
  styleUrls: ['./animalcare.page.scss'],
  imports: [IonicModule]
})
export class AnimalcarePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
