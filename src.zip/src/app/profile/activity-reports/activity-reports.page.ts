import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-activity-reports',
  templateUrl: './activity-reports.page.html',
  styleUrls: ['./activity-reports.page.scss'],
  imports: [IonicModule]
})
export class ActivityReportsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
