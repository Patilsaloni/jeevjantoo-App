import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-inquiries',
  templateUrl: './inquiries.page.html',
  styleUrls: ['./inquiries.page.scss'],
  imports: [IonicModule]
})
export class InquiriesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
