import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-my-listings',
  templateUrl: './my-listings.page.html',
  styleUrls: ['./my-listings.page.scss'],
  imports: [IonicModule]
})
export class MyListingsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
