import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.page.html',
  styleUrls: ['./verification.page.scss'],
  imports: [IonicModule]
})
export class VerificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
