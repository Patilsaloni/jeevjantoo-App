// src/environments/environment.prod.ts
export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyB5b9mW2JUyiIW9GZMNt71tuc71zefomlA",
    authDomain: "jeevjantoo-af3a1.firebaseapp.com",
    projectId: "jeevjantoo-af3a1",
    storageBucket: "jeevjantoo-af3a1.firebasestorage.app",
    messagingSenderId: "256459865200",
    appId: "1:256459865200:web:d25153592d78d7a3f108b5"
  }
};