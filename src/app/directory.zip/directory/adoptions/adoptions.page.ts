import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-adoptions',
  templateUrl: './adoptions.page.html',
  styleUrls: ['./adoptions.page.scss'],
  imports: [IonicModule]
})
export class AdoptionsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
