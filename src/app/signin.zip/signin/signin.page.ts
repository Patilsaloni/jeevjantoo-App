import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

// Firebase imports
import { initializeApp } from 'firebase/app';
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber } from 'firebase/auth';
import { environment } from '../../environments/environment';

declare global {
  interface Window {
    recaptchaVerifier?: RecaptchaVerifier;
  }
}

// Initialize Firebase app
const app = initializeApp(environment.firebaseConfig);
const auth = getAuth(app);

// Optional: Disable reCAPTCHA verification for local testing
auth.settings.appVerificationDisabledForTesting = true;

@Component({
  selector: 'app-signin',
  templateUrl: './signin.page.html',
  styleUrls: ['./signin.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule, FormsModule, ReactiveFormsModule],
})
export class SigninPage implements OnInit, AfterViewInit, OnDestroy {
  loginMode: 'email' | 'phone' = 'email';
  emailForm: FormGroup;
  phoneForm: FormGroup;
  otpSent = false;
  confirmationResult: any;
  recaptchaVerifier?: RecaptchaVerifier;

  constructor(private fb: FormBuilder, private router: Router) {
    // Email form
    this.emailForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });

    // Phone form
    this.phoneForm = this.fb.group({
      phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      otp: ['', Validators.required],
    });
  }

  ngOnInit() {}

  ngAfterViewInit() {
    // Initialize reCAPTCHA after the view is rendered
    setTimeout(() => this.initializeRecaptcha(), 500); // short delay
  }

  ngOnDestroy() {
    // Clear reCAPTCHA to prevent memory leaks
    if (window.recaptchaVerifier) {
      window.recaptchaVerifier.clear();
      window.recaptchaVerifier = undefined;
    }
  }

initializeRecaptcha() {
  if (!window.recaptchaVerifier) {
    try {
      this.recaptchaVerifier = new RecaptchaVerifier(
        auth, // Pass the Auth instance first
        'recaptcha-container', // Container ID or HTMLElement
        {
          size: 'invisible',
          callback: () => console.log('reCAPTCHA verified successfully'),
        }
      );

      window.recaptchaVerifier = this.recaptchaVerifier;

      // Render the reCAPTCHA
      this.recaptchaVerifier.render().then(widgetId => {
        console.log('reCAPTCHA rendered with widgetId:', widgetId);
      });
    } catch (error) {
      console.error('Failed to initialize reCAPTCHA:', error);
    }
  }
}

  // Email login
  onEmailLogin() {
    if (this.emailForm.valid) {
      console.log('Email login data:', this.emailForm.value);
      // Add Firebase email/password login here
    } else {
      alert('Please enter valid email and password');
    }
  }

  // Send OTP to phone
  async onSendOtp() {
    if (!this.phoneForm.get('phone')?.valid) {
      alert('Enter a valid 10-digit phone number');
      return;
    }

    try {
      const phoneNumber = '+91' + this.phoneForm.value.phone;
      const appVerifier = window.recaptchaVerifier;

      if (!appVerifier) {
        alert('reCAPTCHA not initialized. Retrying...');
        this.initializeRecaptcha();
        return;
      }

      this.confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
      this.otpSent = true;
      console.log('OTP sent successfully');
    } catch (error: any) {
      console.error('Error sending OTP:', error);
      alert('Failed to send OTP: ' + error.message);
    }
  }

  // Verify OTP
  async onPhoneLogin() {
    if (!this.phoneForm.valid || !this.otpSent) {
      alert('Please enter a valid OTP');
      return;
    }

    try {
      const result = await this.confirmationResult.confirm(this.phoneForm.value.otp);
      console.log('Phone login successful', result.user);
      this.router.navigate(['/dashboard']);
    } catch (error: any) {
      console.error('Error verifying OTP:', error);
      alert('Invalid OTP: ' + error.message);
    }
  }

  navigateToSignUp() {
    this.router.navigate(['/signup']);
  }

  navigateToForgotPassword() {
    this.router.navigate(['/forgot-password']);
  }
}
